// API: work_areas[] (custom post type WordPress) — icon (slug), number, title,
// description, href (links through to the matching /programmes page),
// image? { src, alt, position } — shown instead of the number + icon row
import Reveal from "./Reveal";

const ICONS = {
  shield: (
    <svg className="work__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3l7 3v6c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3z" />
    </svg>
  ),
  network: (
    <svg className="work__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="9" cy="8" r="3" />
      <path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6" />
      <path d="M16 8a3 3 0 1 0 0-6" />
      <path d="M22 20c0-2.6-1.7-4.8-4-5.6" />
    </svg>
  ),
  document: (
    <svg className="work__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M6 2h9l5 5v15H6z" />
      <path d="M15 2v5h5" />
      <line x1="9" y1="13" x2="15" y2="13" />
      <line x1="9" y1="17" x2="15" y2="17" />
    </svg>
  ),
  connections: (
    <svg className="work__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <line x1="8.6" y1="10.6" x2="15.4" y2="6.4" />
      <line x1="8.6" y1="13.4" x2="15.4" y2="17.6" />
    </svg>
  ),
};

// 2026-11-02 (design review N2): `children` (the expertise pillars) render
// below the programmes grid.
export default function Work({ data, children }) {
  return (
    <section className="work" id="our-work">
      {/* 2026-11-02 (Yv): same split as « Our reach » (.reach__inner) — title,
          text and link in a column on the left, programmes and expertise on
          the right. Previous markup: .work__head > .work__intro (eyebrow +
          title) + .work__summary (text + link), grid full width below. */}
      <div className="work__inner">
        <Reveal as="div" className="work__intro">
          <h2 className="work__title">{data.title}</h2>
          <p className="work__text">{data.text}</p>
          <a className="work__link" href={data.link.href}>
            {data.link.label}
            <svg width="15" height="9" viewBox="0 0 15 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M0 4.5h13M9.4 1 13 4.5 9.4 8" />
            </svg>
          </a>
        </Reveal>

        <div className="work__body">
          <Reveal as="div" className="work__grid" stagger>
            {data.items.map((item) => (
              <a className={`work__item${item.tone ? ` work__item--${item.tone}` : ""}`} href={item.href} key={item.num}>
                {/* 2026-11-04 (at Yv's call, card model supplied): a rounded card
                    tinted with the programme's colour — pill + round arrow on
                    top, title, text — and the photo inset below; every other
                    card flips (photo first, text below), see .work__item:nth-child(even).
                    Previous markup: photo, then h3 + p, on the bare page. */}
                <div className="work__text">
                  <div className="work__meta">
                    <span className="work__pill">{item.num}</span>
                    <span className="work__arrow" aria-hidden="true">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3.5 10.5l7-7M4.5 3.5h6v6" />
                      </svg>
                    </span>
                  </div>
                  <h3 className="work__heading">{item.heading}</h3>
                  <p className="work__desc">{item.desc}</p>
                </div>
                {item.image ? (
                  <div className="work__top work__media" aria-hidden="true">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img className="work__img work__img--base" src={item.image.src} alt="" loading="lazy" style={{ objectPosition: item.image.position }} />
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img className="work__img work__img--color" src={item.image.src} alt="" loading="lazy" style={{ objectPosition: item.image.position }} />
                  </div>
                ) : (
                  <div className="work__top">
                    <span className="work__num">{item.num}</span>
                    {ICONS[item.icon]}
                  </div>
                )}
              </a>
            ))}
          </Reveal>
          {children}
        </div>
      </div>
    </section>
  );
}
