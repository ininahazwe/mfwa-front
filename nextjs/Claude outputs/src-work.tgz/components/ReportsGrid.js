"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import FadeImg from "./FadeImg";

// Sidebar-filtered reports grid (2026-09-27, at Yv's call) — mirrors the
// live site's Publications archive layout (e.g.
// https://mfwa.org/publications/foedr-reports/): a left-hand list of
// report-type filters next to a grid of cards. Every report is fetched
// up front by getReportsPage() and filtering happens entirely
// client-side here — same pattern as the homepage's "topics" filter in
// Latest.js — so clicking a filter is instant, no API round trip.
// `filters` only lists types that actually have at least one matching
// report right now (computed in getReportsPage() from the fetched data,
// not a hardcoded list): a type with zero reports simply never renders a
// button, and reappears on its own once a report using it is published.
// See the note above getWpReports()/mapReport() in lib/wp.js for what
// "filterTerms" actually are and what's still unconfirmed about them.
//
// Found and fixed (2026-09-28) — the actual "grid stays empty" bug: this
// used to wrap the grid in <Reveal stagger>, the same scroll-reveal
// fade-in every other grid on the site uses (CategoryGrid.js). Reveal
// only adds its "is-visible" class (the one thing that takes opacity
// from 0 to 1) once an IntersectionObserver reports the element at
// least 15% inside the viewport. That works for CategoryGrid because it
// paginates ("load more"), so its grid stays short. Reports deliberately
// loads its WHOLE corpus at once for instant client-side filtering (Yv's
// original ask) — with 45+ cards that makes the grid several times
// taller than the screen, so even a full viewport's worth of it in view
// is well under 15% of its TOTAL height, and the 15% threshold is never
// crossed: the grid sat at opacity:0 forever, invisible but fully
// present in the DOM (which is why `.reports-grid .story` always
// counted correctly in tests, and why disabling the filters or fixing
// the data fetch — see lib/wp.js's retry/522 and 2MB-cache fixes —
// never helped: neither one touched this). Fix: this grid no longer
// uses Reveal at all — it renders as a plain div, visible immediately,
// which also suits a fully-loaded, instantly-filterable list better
// than a scroll-in animation anyway.
// Same initial page size CategoryGrid.js uses for its own "load more"
// grids, so Reports doesn't stand out from the rest of the site.
const PAGE_SIZE = 12;

export default function ReportsGrid({ articles, filters, categories = [], initialCategory }) {
  const [activeFilter, setActiveFilter] = useState(null);
  // Programme tabs (retours équipe com #11, 2026-10-16): the live site's 3
  // higher-level report groupings. `initialCategory` comes from
  // /reports?category=<slug> (the "Browse the reports" button on each
  // programme page); an unknown slug just means "All".
  const [activeCategory, setActiveCategory] = useState(
    categories.some((c) => c.slug === initialCategory) ? initialCategory : null
  );
  // "hasMore" pagination (2026-09-28, at Yv's call), on top of the fix
  // above: everything is still fetched and filtered up front (no extra
  // API round trip — the whole point of this page), but only
  // `displayCount` of the current, already-filtered list is actually
  // rendered at a time, with a "Load more" button underneath — same
  // pattern as CategoryGrid.js's own hasMore/"load more", just driven
  // from the in-memory list instead of another page fetch. This also
  // keeps the DOM (and the page's real height) from ballooning to
  // hundreds of cards at once on an archive that keeps growing.
  const [displayCount, setDisplayCount] = useState(PAGE_SIZE);

  const filtered = useMemo(() => {
    return articles.filter(
      (story) =>
        (!activeFilter || story.filterTerms.some((f) => f.slug === activeFilter)) &&
        (!activeCategory || (story.categoryTerms ?? []).some((c) => c.slug === activeCategory))
    );
  }, [activeFilter, activeCategory, articles]);

  // Switching filters always starts back at the first page — otherwise
  // "Annual Reports" could open already expanded to however many cards
  // "All" happened to be showing, which reads as broken rather than
  // filtered.
  function selectFilter(slug) {
    setActiveFilter(slug);
    setDisplayCount(PAGE_SIZE);
  }
  function selectCategory(slug) {
    setActiveCategory(slug);
    setDisplayCount(PAGE_SIZE);
  }

  const visible = filtered.slice(0, displayCount);
  const hasMore = displayCount < filtered.length;

  const grid = (
    <>
      <div className="reports-grid">
        {visible.map((story, i) => (
          <ReportCard story={story} key={`${story.link}-${i}`} />
        ))}
      </div>
      {filtered.length === 0 && <p className="reports-empty">No reports in this category yet.</p>}
      {hasMore && (
        <div className="category__loadmore">
          <button type="button" className="btn btn--loadmore" onClick={() => setDisplayCount((c) => c + PAGE_SIZE)}>
            Load more
          </button>
        </div>
      )}
    </>
  );

  // Sidebar redesign (2026-10-18, at Yv's call — inspired by a classic app
  // side-nav: a heading block with a muted sub-line, a hairline, then
  // roomy icon + label rows, the active row marked only by a vertical
  // accent bar on the left edge; no pills, no filled backgrounds). Both
  // report-type filters (.reports-filters) live in that left column; the
  // programme tabs (.reports-tabs) stay a horizontal row above the grid.
  // Same state, same filtering as before; only the markup/CSS changed.
  // Revert: ReportsGrid.js.bak-reports-nav + globals.css.bak-reports-nav.
  const byCategory = activeCategory
    ? articles.filter((story) => (story.categoryTerms ?? []).some((c) => c.slug === activeCategory))
    : articles;
  const typeCounts = {};
  for (const story of byCategory) {
    for (const f of story.filterTerms ?? []) typeCounts[f.slug] = (typeCounts[f.slug] ?? 0) + 1;
  }

  // Programme tabs stay horizontal, above the grid (Yv, 2026-10-18): same
  // row styling as the side-nav (icon + label + count, active = red bar,
  // here along the bottom edge), no group heading.
  const tabs =
    categories.length > 0 ? (
      <nav className="reports-tabs" aria-label="Browse reports by programme">
        <SideButton
          className="reports-tabs__btn"
          active={!activeCategory}
          icon="all"
          label="All reports"
          count={articles.length}
          onClick={() => selectCategory(null)}
        />
        {categories.map((c) => (
          <SideButton
            key={c.slug}
            className="reports-tabs__btn"
            active={activeCategory === c.slug}
            icon={categoryIcon(c.slug)}
            label={c.slug === "annual-reports" ? c.name : c.name.replace(/ Reports$/, "")}
            count={c.count}
            onClick={() => selectCategory(c.slug)}
          />
        ))}
      </nav>
    ) : null;

  const types =
    filters.length > 0 ? (
      <div className="reports-group">
        <div className="reports-group__head">
          <p className="reports-group__title">Report type</p>
          <p className="reports-group__sub">
            {filters.length} {filters.length > 1 ? "types" : "type"}
          </p>
        </div>
        <nav className="reports-filters" aria-label="Filter reports by type">
          <SideButton
            className="reports-filters__btn"
            active={!activeFilter}
            icon="layers"
            label="All"
            count={byCategory.length}
            onClick={() => selectFilter(null)}
          />
          {filters.map((f) => (
            <SideButton
              key={f.slug}
              className="reports-filters__btn"
              active={activeFilter === f.slug}
              icon={typeIcon(f)}
              label={f.name}
              count={typeCounts[f.slug] ?? 0}
              dim={!typeCounts[f.slug] && activeFilter !== f.slug}
              onClick={() => selectFilter(f.slug)}
            />
          ))}
        </nav>
      </div>
    ) : null;

  // Mobile: the two groups become horizontally scrolling rows — keep the
  // active row in view (e.g. /reports?category=mdgg-reports preselects the
  // last tab, which would otherwise start off-screen). Desktop: no-op.
  const sideRef = useRef(null);
  useEffect(() => {
    sideRef.current?.querySelectorAll(".reports-tabs, .reports-filters").forEach((row) => {
      const btn = row.querySelector(".is-active");
      if (btn && row.scrollWidth > row.clientWidth) row.scrollLeft = Math.max(0, btn.offsetLeft - row.offsetLeft - 16);
    });
  }, [activeCategory, activeFilter]);

  if (!types) {
    return (
      <div ref={sideRef}>
        {tabs}
        {grid}
      </div>
    );
  }

  return (
    <div className="reports-layout" ref={sideRef}>
      <aside className="reports-side">{types}</aside>
      <div className="reports-main">
        {tabs}
        {grid}
      </div>
    </div>
  );
}

/* ---------- side-nav rows ---------- */

function SideButton({ className, active, icon, label, count, dim, onClick }) {
  return (
    <button
      type="button"
      className={`reports-side__btn ${className}${active ? " is-active" : ""}${dim ? " is-dim" : ""}`}
      aria-pressed={active}
      onClick={onClick}
    >
      <span className="reports-side__icon" aria-hidden="true">
        {SIDE_ICONS[icon] ?? SIDE_ICONS.doc}
      </span>
      <span className="reports-side__label">{label}</span>
      <span className="reports-side__count">{count}</span>
    </button>
  );
}

function categoryIcon(slug) {
  if (/annual/.test(slug)) return "calendar";
  if (/foe|expression|digital/.test(slug)) return "mic";
  if (/mdgg|democracy|governance/.test(slug)) return "newspaper";
  return "folder";
}

function typeIcon(f) {
  const key = `${f.slug} ${f.name}`.toLowerCase();
  if (/annual/.test(key)) return "calendar";
  if (/monitor/.test(key)) return "eye";
  if (/month|quarter/.test(key)) return "clock";
  if (/polic|brief|paper/.test(key)) return "doc";
  if (/research/.test(key)) return "search";
  if (/analy/.test(key)) return "bars";
  if (/strateg|framework/.test(key)) return "compass";
  return "doc";
}

// Bold, geometric 24px icons (2px stroke, round joins) — the weight of the
// reference's icons, drawn in the site's own line-icon language.
const ico = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2.1,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};
const SIDE_ICONS = {
  all: (
    <svg {...ico}>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" fill="currentColor" />
    </svg>
  ),
  layers: (
    <svg {...ico}>
      <path d="M12 3 21 8l-9 5-9-5 9-5z" fill="currentColor" />
      <path d="m3 12.5 9 5 9-5" />
      <path d="m3 17 9 5 9-5" />
    </svg>
  ),
  calendar: (
    <svg {...ico}>
      <rect x="3.5" y="5" width="17" height="15.5" rx="2" />
      <path d="M3.5 10h17M8 3v4M16 3v4" />
      <rect x="7" y="13" width="3.5" height="3.5" rx=".6" fill="currentColor" stroke="none" />
    </svg>
  ),
  mic: (
    <svg {...ico}>
      <rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor" />
      <path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21" />
    </svg>
  ),
  newspaper: (
    <svg {...ico}>
      <rect x="3" y="5" width="14" height="14" rx="1.5" />
      <path d="M17 8h4v9a2 2 0 0 1-2 2H7" />
      <path d="M6.5 9h6M6.5 12h6M6.5 15h3" />
    </svg>
  ),
  folder: (
    <svg {...ico}>
      <path d="M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.5h8.5A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z" />
    </svg>
  ),
  eye: (
    <svg {...ico}>
      <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" fill="currentColor" />
    </svg>
  ),
  clock: (
    <svg {...ico}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
  doc: (
    <svg {...ico}>
      <path d="M6 3h8l4 4v14H6z" />
      <path d="M14 3v4h4M9 12h6M9 16h6" />
    </svg>
  ),
  search: (
    <svg {...ico}>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m19.5 19.5-4.6-4.6" />
    </svg>
  ),
  bars: (
    <svg {...ico}>
      <path d="M4 20h16" />
      <rect x="5.5" y="11" width="3" height="6.5" rx=".8" fill="currentColor" />
      <rect x="10.5" y="6" width="3" height="11.5" rx=".8" fill="currentColor" />
      <rect x="15.5" y="9" width="3" height="8.5" rx=".8" fill="currentColor" />
    </svg>
  ),
  compass: (
    <svg {...ico}>
      <circle cx="12" cy="12" r="8.5" />
      <path d="m15.5 8.5-2 5-5 2 2-5z" fill="currentColor" />
    </svg>
  ),
};

function ReportCard({ story }) {
  return (
    <article className="story">
      <a className="story__link" href={story.link}>
        <figure className={`story__media${story.image.isFallback ? " story__media--fallback" : ""}`}>
          <FadeImg src={story.image.src} alt={story.image.alt} removeOnError={!story.image.isFallback} />
        </figure>
        <div className="story__body">
          <h3 className="story__heading">{story.heading}</h3>
          <p className="story__meta">
            <span>{story.date}</span>
            <svg
              className="story__arrow"
              width="15"
              height="9"
              viewBox="0 0 15 9"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M0 4.5h13M9.4 1 13 4.5 9.4 8" />
            </svg>
          </p>
        </div>
      </a>
    </article>
  );
}
