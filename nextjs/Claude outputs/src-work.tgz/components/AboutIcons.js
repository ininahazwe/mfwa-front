// Line icons shared by the About page sections — same 1.6 stroke,
// round-cap language as the icons in Work.js / Expertise.js, drawn at
// 24×24 and sized by CSS.

const base = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true",
};

export const ICONS = {
  voice: (
    <svg {...base}>
      <path d="M4 10v4h3l6 4V6L7 10z" />
      <path d="M16.5 9a4 4 0 0 1 0 6" />
      <path d="M19 6.5a7.5 7.5 0 0 1 0 11" />
    </svg>
  ),
  eye: (
    <svg {...base}>
      <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  ),
  target: (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1.2" fill="currentColor" />
    </svg>
  ),
  compass: (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <path d="m15.5 8.5-2 5-5 2 2-5z" />
    </svg>
  ),
  spark: (
    <svg {...base}>
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" />
    </svg>
  ),
  team: (
    <svg {...base}>
      <circle cx="9" cy="8" r="3" />
      <path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6" />
      <path d="M16 8a3 3 0 1 0 0-6" />
      <path d="M22 20c0-2.6-1.7-4.8-4-5.6" />
    </svg>
  ),
  board: (
    <svg {...base}>
      <path d="M3 9 12 4l9 5" />
      <path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8" />
      <path d="M3 20h18" />
    </svg>
  ),
  globe: (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3c2.5 2.6 3.8 5.6 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z" />
    </svg>
  ),
  quote: (
    <svg {...base}>
      <path d="M5 17c0-4 1-7 5-9" />
      <path d="M5 13h4v4H5z" fill="currentColor" stroke="none" />
      <path d="M14 17c0-4 1-7 5-9" />
      <path d="M14 13h4v4h-4z" fill="currentColor" stroke="none" />
    </svg>
  ),
  mic: (
    <svg {...base}>
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5.5 11a6.5 6.5 0 0 0 13 0" />
      <path d="M12 17.5V21" />
    </svg>
  ),
  shield: (
    <svg {...base}>
      <path d="M12 3l7 3v6c0 4.5-3 8-7 9-4-1-7-4.5-7-9V6l7-3z" />
    </svg>
  ),
  // Contact page (2026-09-28): address/phone/email card icons.
  pin: (
    <svg {...base}>
      <path d="M12 21s7-6.4 7-11.5A7 7 0 0 0 5 9.5C5 14.6 12 21 12 21z" />
      <circle cx="12" cy="9.5" r="2.4" />
    </svg>
  ),
  phone: (
    <svg {...base}>
      <path d="M5.5 4h3l1.5 4-2 1.5a11 11 0 0 0 5.5 5.5l1.5-2 4 1.5v3c0 1.1-.9 2-2 2C10.5 19.5 4.5 13.5 4.5 6.5c0-1.1.9-2.1 2-2.1z" />
    </svg>
  ),
  mail: (
    <svg {...base}>
      <rect x="3" y="5" width="18" height="14" rx="2.4" />
      <path d="m4 6.5 8 6 8-6" />
    </svg>
  ),
  // Programme hub cards (2026-09-30): CardNav.js used a generic "globe" for
  // all five programmes — these three, plus the existing "mic" and "quote"
  // above, give each one its own small-scale echo of its Motif.js variant
  // (see PROGRAMME_TILES in lib/content.js), simplified for 24px instead
  // of the bigger, more detailed decorative motif.
  orbit: (
    <svg {...base}>
      <circle cx="12" cy="12" r="8" />
      <circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none" />
      <circle cx="19" cy="8.5" r="1.3" fill="currentColor" stroke="none" />
    </svg>
  ),
  newspaper: (
    <svg {...base}>
      <rect x="3" y="5" width="14" height="14" rx="1.5" />
      <path d="M17 8h4v9a2 2 0 0 1-2 2H7" />
      <path d="M6.5 9h6M6.5 12h6M6.5 15h3" />
    </svg>
  ),
  search: (
    <svg {...base}>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m19.5 19.5-4.6-4.6" />
    </svg>
  ),
};

export const ARROW_RIGHT = (
  <svg width="15" height="9" viewBox="0 0 15 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M0 4.5h13M9.4 1 13 4.5 9.4 8" />
  </svg>
);

export const ARROW_DIAGONAL = (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M2 12 12 2M4.5 2H12v7.5" />
  </svg>
);

export const PLUS = (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
    <path d="M7 1v12M1 7h12" />
  </svg>
);
