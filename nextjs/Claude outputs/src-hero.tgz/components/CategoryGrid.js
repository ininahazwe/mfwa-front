"use client";

import { useEffect, useRef, useState } from "react";
import Reveal from "./Reveal";
import StoryMedia from "./StoryMedia";

const AUTO_LOAD_LIMIT = 3; // number of scroll-triggered batches before the button takes over

// apiBase lets this same grid drive the "Where We Work" country archives
// (app/api/country/[slug]/posts) and the single "Our Impact" archive
// (app/api/impact-stories/posts, no per-term slug) as well as category
// archives — all identical in shape (see getCountryPage/
// getImpactStoriesPage in lib/content.js), so this generalizes the
// differences (API path, page size) instead of duplicating ~120 lines of
// load-more/IntersectionObserver logic. `slug` is omitted for an archive
// that isn't per-term, like Impact Stories.
//
// `extraParams` covers the one case `slug`-in-path doesn't: the merged
// Where We Work × Issues explorer (app/api/where-we-work/posts), which
// has TWO independent optional filters (country, category) rather than
// one required slug — those go on the query string instead. Keys with a
// null/undefined/empty value are dropped rather than being sent as the
// literal string "undefined".
export default function CategoryGrid({
  slug,
  initialItems,
  initialTotalPages,
  initialTotal,
  apiBase = "/api/category",
  endMessage = "You've reached the end of this category.",
  pageSize = 10,
  extraParams = {},
}) {
  const [items, setItems] = useState(initialItems);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(initialTotalPages);
  const [total, setTotal] = useState(initialTotal);
  const [autoLoadCount, setAutoLoadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const sentinelRef = useRef(null);
  const loadingRef = useRef(false);

  const hasMore = page < totalPages;
  const autoExhausted = autoLoadCount >= AUTO_LOAD_LIMIT;

  function loadMore(isAuto) {
    if (loadingRef.current || !hasMore) return;
    loadingRef.current = true;
    setLoading(true);
    setError(null);

    const nextPage = page + 1;
    const qs = new URLSearchParams(
      Object.fromEntries(
        Object.entries({ page: nextPage, perPage: pageSize, ...extraParams }).filter(
          ([, v]) => v !== null && v !== undefined && v !== ""
        )
      )
    ).toString();
    fetch(`${apiBase}${slug ? `/${slug}` : ""}/posts?${qs}`)
      .then((res) => {
        if (!res.ok) throw new Error("request-failed");
        return res.json();
      })
      .then((data) => {
        setItems((prev) => [...prev, ...data.items]);
        setPage(data.page);
        setTotalPages(data.totalPages);
        setTotal(data.total);
        if (isAuto) setAutoLoadCount((count) => count + 1);
      })
      .catch(() => {
        setError("We couldn't load more stories. Please try again.");
      })
      .finally(() => {
        loadingRef.current = false;
        setLoading(false);
      });
  }

  useEffect(() => {
    if (autoExhausted || !hasMore || error) return undefined;
    const el = sentinelRef.current;
    if (!el || !("IntersectionObserver" in window)) return undefined;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) loadMore(true);
        });
      },
      { rootMargin: "0px 0px 200px 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoExhausted, hasMore, error, page]);

  return (
    <>
      {/*<p className="category__count">Showing {items.length} of {total} stories</p>*/}
      <Reveal as="div" className="category__grid" stagger>
        {items.map((story, i) => (
          <article className="story" key={`${story.link}-${i}`}>
            <a className="story__link" href={story.link}>
              <StoryMedia story={story} />
              <div className="story__body">
                {story.tag.length > 0 && (
                  <p className="story__tag">
                    {story.tag[0]}
                    {story.tag[1] && <><span>·</span> {story.tag[1]}</>}
                  </p>
                )}
                <h3 className="story__heading">{story.heading}</h3>
                <p className="story__meta">
                  <span>
                    {story.date}
                    {story.readTime && <><i>·</i> {story.readTime}</>}
                  </span>
                  <svg className="story__arrow" width="15" height="9" viewBox="0 0 15 9" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M0 4.5h13M9.4 1 13 4.5 9.4 8" /></svg>
                </p>
              </div>
            </a>
          </article>
        ))}
      </Reveal>

      {hasMore && !autoExhausted && !error && (
        <div ref={sentinelRef} className="category__sentinel" aria-hidden="true" />
      )}

      {loading && !error && <p className="category__loading" role="status">Loading more stories…</p>}

      {error && (
        <div className="category__error" role="alert">
          <p>{error}</p>
          <button type="button" className="btn btn--loadmore category__retry" onClick={() => loadMore(false)}>
            Try again
          </button>
        </div>
      )}

      {hasMore && autoExhausted && !error && (
        <div className="category__loadmore">
          <button type="button" className="btn btn--loadmore" onClick={() => loadMore(false)} disabled={loading}>
            {loading ? "Loading…" : "Load more"}
          </button>
        </div>
      )}

      {!hasMore && !error && <p className="category__end">{endMessage}</p>}
    </>
  );
}
